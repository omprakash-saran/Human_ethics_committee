import BgImage from '../../components/bgImage/BgImage';
import styles from './Resources.module.css';

const Resources = () => {
  return (
    <div className={styles.container}>
      <BgImage text='Resources' />

      <div className={`${styles.subcontainer}`}>

        <div className={`${styles.bioSafety}`} id='bioSafety'>
          <div className={`${styles.title}`}>BioSafety</div>
          <a href="https://iitr.ac.in/Departments/Biosciences%20and%20Bioengineering%20Department/Miscellaneous/IBSC%20.html">Bio safety members and protocols</a>
        </div>

        <div className={`${styles.internalResources}`} id='internalResources'>
          <div className={`${styles.title}`}>Internal Resources</div>
        </div>

        <div className={`${styles.externalResources}`} id='externalResources'>
          <div className={`${styles.title}`}>External Resources</div>
        </div>

      </div>
    </div>
  );
};

export default Resources;